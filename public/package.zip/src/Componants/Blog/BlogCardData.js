const blogData = [
  {
    id: 1,
    title: "Changing Trends In Marketing",
    content:
      "Changing trends in marketing in 2018, Changing the way businesses are marketing products.",
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2016/06/03/13/57/digital-marketing-1433427_1280.jpg",
    link: "/blog/page1",
  },
  {
    id: 2,
    title: "5 Strategies for Building a Strong Personal Brand",
    content: " In todays competitive professional landscape, building...",
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2017/07/31/11/21/people-2557396_1280.jpg",
    link: "/blog/page2",
  },
  {
    id: 3,
    title: "10 Essential Tips for Writing Engaging LinkedIn Articles",
    content: " LinkedIn has become a powerful platform for professionals ...",
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2016/06/03/13/57/digital-marketing-1433427_640.jpg",
    link: "/blog/page3",
  },
  {
    id: 4,
    title: "10 Proven Strategies to Boost Your LinkedIn Engagement",
    content: " LinkedIn has become a powerful platform for professionals  ...",
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2016/10/20/08/53/keyboard-1754921_960_720.jpg",
    link: "/blog/page4",
  },
  {
    id: 5,
    title:
      "AI Powered Personalization Tailoring Marketing Messages for Individuals",
    content:
      " In an era where attention spans are shrinking, and consumers   ...",
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2019/06/19/07/13/email-4284157_1280.png",
    link: "/blog/page5",
  },
  {
    id: 6,
    title:
      "Alumni Amplified The Art of Connecting on LinkedIn for Lifelong Success",
    content:
      " Alumni Amplified The Art of Connecting on LinkedIn for Lifelong Success  ...",
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2023/10/25/07/02/lecturer-8339699_640.jpg",
    link: "/blog/page6",
  },
  {
    id: 7,
    title: "Augmented Reality Marketing Blending Real and Digital Worlds",
    content:
      " The digital revolution has transformed the way businesses engage   ...",
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2018/01/06/07/53/social-3064515_640.jpg",
    link: "/blog/page7",
  },
  {
    id: 8,
    title: "Authentic Networking Building Genuine Connections on LinkedIn",
    content:
      " In professional networking, authenticity has become paramount  ...",
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2018/02/16/16/07/linkedin-3157977_1280.jpg",
    link: "/blog/page8",
  },
  {
    id: 9,
    title:
      "Beyond Channels Crafting Unified Experiences with Transmedia Marketing for Engaging Audiences",
    content:
      " In professional networking, authenticity has become paramount  ...",
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2015/07/17/22/42/typing-849806_640.jpg",
    link: "/blog/page9",
  },
  {
    id: 10,
    title:
      "Beyond Distance Mastering Effective Communication in a Virtual Work Environment",
    content:
      " In the era of remote work, effective communication has become   ...",
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2022/12/30/04/38/offices-7686219_640.jpg",
    link: "/blog/page10",
  },
  {
    id: 11,
    title:
      "Beyond Impressions Decoding Conversion Chronicles in Influencer Marketing",
    content:
      "In the dynamic world of influencer marketing, where impressions   ...",
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2019/04/29/07/04/software-development-4165307_640.jpg",
    link: "/blog/page11",
  },
  {
    id: 12,
    title:
      "Beyond Impressions Unveiling the Impact of Social Media Advertising on Brand Awareness",
    content:
      "In the dynamic world of influencer marketing, where impressions   ...",
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2015/03/18/20/35/wordcloud-679951_1280.png",
    link: "/blog/page12",
  },
  {
    id: 13,
    title: "Beyond Likes Nurturing Loyalty in the Social Media Era",
    content:
      "In todays digital landscape, social media stands as a pivotal   ...",
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2016/06/19/08/43/marketing-1466315_640.jpg",
    link: "/blog/page13",
  },
  {
    id: 14,
    title: "Beyond Likes Unleashing the Power of Shares  Decoding the ",
    content:
      "In the dynamic landscape of social media, where content reigns    ...",
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2021/03/29/18/57/social-media-6134993_1280.png",
    link: "/blog/page14",
  },
  {
    id: 15,
    title:
      "Beyond Profit Navigating the Landscape of Social Impact Marketing for Startups",
    content:
      "In the dynamic landscape of social media, where content reigns    ...",
    date: "7 March",
    name: " Sharad Koche",
    img: "https://media.istockphoto.com/id/1385970223/photo/great-idea-of-a-marketing-strategy-plan-at-a-creative-office.jpg?s=612x612&w=0&k=20&c=6up_J8ekhYIbF3qiUEo9t28u8X-UrFNqwryyRhBl35w=",
    link: "/blog/page15",
  },
  {
    id: 16,
    title: "Beyond Profit The Strategic Imperative of Corporate Social ",
    content:
      "In the evolving landscape of corporate dynamics, a paradigm s    ...",
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2016/06/13/09/57/meeting-1453895_640.png",
    link: "/blog/page16",
  },
  {
    id: 17,
    title: "Beyond Reach Navigating the Journey from Social Media ",
    content: "In the bustling world of social media, the transition   ...",
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2016/09/29/23/01/revenue-1704073_1280.png",
    link: "/blog/page17",
  },
  {
    id: 18,
    title:
      "Beyond Representation Navigating Inclusive Marketing Celebrating Diversity and Embracing Equality ",
    content: "In the ever-evolving landscape of marketing, inclusivity    ...",
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2022/11/09/09/29/business-7580148_1280.png",
    link: "/blog/page18",
  },
  {
    id: 19,
    title:
      "Beyond Screens Crafting Unforgettable Experiences with Experiential Marketing ",
    content:
      "In a world dominated by screens and digital interactions,     ...",
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2020/12/16/15/19/mobile-phone-5836879_640.png",
    link: "/blog/page19",
  },
  {
    id: 20,
    title: "Beyond the Buzz Advanced Social Media Analytics and the Art ",
    content: "In the era of digital connectivity, social media has      ...",
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2020/11/08/12/39/laptop-5723603_1280.png",
    link: "/blog/page20",
  },
  {
    id: 21,
    title: "Beyond the Click The Evolution of Interactive Email Marketin ",
    content:
      "  Email marketing has evolved from static messages to dynamic      ...",
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2021/03/19/12/37/man-6107457_640.png",
    link: "/blog/page21",
  },
  {
    id: 22,
    title: "Representation Navigating Inclusive Marketing ",
    content:
      "  Social media influencers wield significant influence over      ...",
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2016/06/13/15/07/presentation-1454403_640.png",
    link: "/blog/page22",
  },
  {
    id: 23,
    title:
      "Beyond the Like Unveiling the Influence of Social Proof in Influencer ",
    content:
      "Influencer marketing has evolved significantly, with social     ...",
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2018/01/13/20/58/business-3080799_640.png",
    link: "/blog/page23",
  },
  {
    id: 24,
    title: "Beyond Titles Personal Branding for Founders A Blueprint ",
    content:
      "In todays competitive entrepreneurial landscape, a founders      ...",
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2022/10/31/05/14/arrows-7558940_640.png",
    link: "/blog/page24",
  },
  {
    id: 25,
    title: "Beyond Titles Personal Branding for Founders A Blueprint ",
    content: "In the realm of customer engagement, the ability    ...",
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2018/03/22/02/37/email-3249062_640.png",
    link: "/blog/page25",
  },
  {
    id: 26,
    title: "Beyond Words Harnessing the Power of Neuro Linguistic  ",
    content:
      'In "Mastering Persuasive Brand Messaging with NLP Techniques    ...',
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2016/09/11/05/34/whatsapp-interface-1660652_640.png",
    link: "/blog/page26",
  },
  {
    id: 40,
    title: "The Art of Persuasion Psychology in Marketing",
    content:
      'Marketing is often seen as the art of persuasion. Behind every  ...',
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2017/12/06/07/41/head-3001159_1280.jpg",
    link: "/blog/page40",
  },
  {
    id: 41,
    title: "The Art of Public Speaking Tips for Captivating Presentations",
    content:
      ' Public speaking, often perceived as a daunting task, holds immense...',
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2018/02/17/05/35/public-speaking-3159217_1280.jpg",
    link: "/blog/page41",
  },
  {
    id: 42,
    title: "The Art of Self Discovery Uncover Your True Self",
    content:
      ' In the hustle and bustle of our daily...',
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2022/07/07/10/46/woman-7306978_1280.jpg",
    link: "/blog/page42",
  },
  {
    id: 43,
    title: "The Art of Storytelling Crafting Compelling Narratives for Startup Brands",
    content:
      ' In the dynamic and competitive world of startups...',
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2018/03/27/21/43/startup-3267505_1280.jpg",
    link: "/blog/page43",
  },
  {
    id: 44,
    title: "The Art of Storytelling in Marketing Weaving Narratives ",
    content:
      'In the ever-evolving landscape of marketing, one timel...',
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2015/07/17/22/43/student-849826_1280.jpg",
    link: "/blog/page44",
  },
  {
    id: 45,
    title: "The Art of Writing a Compelling LinkedIn Headline",
    content:
      'In the world of professional networking, your LinkedIn...',
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2015/09/05/07/28/writing-923882_1280.jpg",
    link: "/blog/page45",
  },
  {
    id: 46,
    title: "The Benefits of Joining LinkedIn Groups",
    content:
      'In the world of professional networking, your LinkedIn...',
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2016/11/03/18/19/social-media-1795578_1280.jpg",
    link: "/blog/page46",
  },
  {
    id: 47,
    title: "The Benefits of Mentorship in Career Development",
    content:
      'In todays rapidly evolving professional landscape, career  ...',
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2018/03/17/10/51/post-it-notes-3233653_1280.jpg",
    link: "/blog/page47",
  },
  {
    id: 48,
    title: "The Dos and Don'ts of LinkedIn Networking Building Meaningful Connections",
    content:
      'In todays digital age, LinkedIn has become a powerful   ...',
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2021/06/25/12/26/social-media-6363633_1280.jpg",
    link: "/blog/page48",
  },
 
  {
    id: 49,
    title: "The Dos and Don'ts of LinkedIn Networking",
    content:
      'LinkedIn has emerged as the premier platform for ...',
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2018/06/28/18/09/linkedin-3504469_1280.jpg",
    link: "/blog/page49",
  },
  {
    id: 50,
    title: "The Benefits of Joining LinkedIn Groups",
    content:
      'In todays rapidly evolving professional landscape, career  ...',
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2018/03/17/10/51/post-it-notes-3233653_1280.jpg",
    link: "/blog/page47",
  },
  {
    id: 51,
    title: "The Benefits of Mentorship in Career Development",
    content:
      'In todays rapidly evolving professional landscape  ...',
    date: "7 March",
    name: " Sharad Koche",
    img: "https://cdn.pixabay.com/photo/2019/02/03/11/04/economy-3972328_1280.jpg",
    link: "/blog/page51",
  },
 
];

export default blogData;
