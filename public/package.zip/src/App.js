
import './App.css';
import { BrowserRouter as Router, Route, Routes, Switch } from 'react-router-dom'
import Home from './Componants/Home/Home.js'
import Navbar from './Componants/Navbar/Navbar';
import Footer from './Componants/Footer/Footer'
import Project from './Componants/Project/Project'
import Plan from './Componants/Plan/Plan'
import BlogPage from './Componants/Blog/BlogPage'
import { page1Data } from './Componants/Blog/Data/Page1Data';
import { page2Data } from './Componants/Blog/Data/Page2Data';
import { page3Data } from './Componants/Blog/Data/Page3Data';
import { page4Data } from './Componants/Blog/Data/Page4Data';
// import { page5Data } from './Componants/Blog/Data/Page5.Data.js';
import { page5Data } from './Componants/Blog/Data/Page5Data.js';
import { page6Data } from './Componants/Blog/Data/Page6Data.js';
import { page7Data } from './Componants/Blog/Data/Page7Data.js';
import { page8Data } from './Componants/Blog/Data/Page8Data.js';
import { page9Data } from './Componants/Blog/Data/Page9Data.js';
import { page10Data } from './Componants/Blog/Data/Page10Data.js';
import { page11Data } from './Componants/Blog/Data/Page11Data.js';
import { page12Data } from './Componants/Blog/Data/Page12Data.js';
import { page13Data } from './Componants/Blog/Data/Page13Data.js';
import { page14Data } from './Componants/Blog/Data/Page14Data.js';
import { page15Data } from './Componants/Blog/Data/Page15Data.js';
import { page16Data } from './Componants/Blog/Data/Page16Data.js';
import { page17Data } from './Componants/Blog/Data/Page17Data.js';
import { page18Data } from './Componants/Blog/Data/Page18Data.js';
import { page19Data } from './Componants/Blog/Data/Page19Data.js';
import { page20Data } from './Componants/Blog/Data/Page20Data.js';
import { page21Data } from './Componants/Blog/Data/Page21Data.js';
import { page22Data } from './Componants/Blog/Data/Page22Data.js';
import { page23Data } from './Componants/Blog/Data/Page23Data.js';
import { page24Data } from './Componants/Blog/Data/Page24Data.js';
import { page25Data } from './Componants/Blog/Data/Page25Data.js';
import { page26Data } from './Componants/Blog/Data/Page26Data.js';
import { page40Data } from './Componants/Blog/Data/Page40Data';
import { page41Data } from './Componants/Blog/Data/Page41Data';
import { page42Data } from './Componants/Blog/Data/Page42Data';
import { page43Data } from './Componants/Blog/Data/Page43Data';
import { page44Data } from './Componants/Blog/Data/Page44Data';
import { page45Data } from './Componants/Blog/Data/Page45Data';
import { page46Data } from './Componants/Blog/Data/Page46Data';
import { page47Data } from './Componants/Blog/Data/Page47Data';
import { page48Data } from './Componants/Blog/Data/Page48Data';
import { page49Data } from './Componants/Blog/Data/Page49Data';
import { page51Data } from './Componants/Blog/Data/Page51Data';



import Blog from './Componants/Blog/Blog';
import Contact from './Componants/Contact Us/Contact'
import BlogPageExpand1 from './Componants/Blog/BlogPageExpand1'
import BlogPageExpand2 from './Componants/Blog/BlogPageExpand2'



function App() {
  return (
    <div className="App">
      <Router>
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          {/* <Route path="/about" element={<About />} /> */}
          <Route path="/project" element={<Project/>} />
          <Route path="/plan" element={<Plan/>} />
          <Route extact path="/blog" exact element = {<Blog/>} />
          <Route extact path="/blog1" exact element = {<BlogPageExpand1/>} />
          <Route extact path="/blog2" exact element = {<BlogPageExpand2/>} />
          <Route extact path="/contact" exact element = {<Contact/>} />
          <Route extact path="/blog/blog" exact element = {<Blog/>} />
          <Route exact path="/blog/page1" element={ <BlogPage data={page1Data} />} />
        <Route path="/blog/page2" element={ <BlogPage data={page2Data} />} />
        <Route path="/blog/page3" element={ <BlogPage data={page3Data} />} />
        <Route path="/blog/page4" element={ <BlogPage data={page4Data} />} />
        <Route path="/blog/page5" element={ <BlogPage data={page5Data} />} />
        <Route path="/blog/page6" element={ <BlogPage data={page6Data} />} />
        <Route path="/blog/page7" element={ <BlogPage data={page7Data} />} />
        <Route path="/blog/page8" element={ <BlogPage data={page8Data} />} />
        <Route path="/blog/page9" element={ <BlogPage data={page9Data} />} />
        <Route path="/blog/page10" element={ <BlogPage data={page10Data} />} />
        <Route path="/blog/page11" element={ <BlogPage data={page11Data} />} />
        <Route path="/blog/page12" element={ <BlogPage data={page12Data} />} />
        <Route path="/blog/page13" element={ <BlogPage data={page13Data} />} />
        <Route path="/blog/page14" element={ <BlogPage data={page14Data} />} />
        <Route path="/blog/page15" element={ <BlogPage data={page15Data} />} />
        <Route path="/blog/page16" element={ <BlogPage data={page16Data} />} />
        <Route path="/blog/page17" element={ <BlogPage data={page17Data} />} />
        <Route path="/blog/page18" element={ <BlogPage data={page18Data} />} />
        <Route path="/blog/page19" element={ <BlogPage data={page19Data} />} />
        <Route path="/blog/page20" element={ <BlogPage data={page20Data} />} />
        <Route path="/blog/page21" element={ <BlogPage data={page21Data} />} />
        <Route path="/blog/page22" element={ <BlogPage data={page22Data} />} />
        <Route path="/blog/page23" element={ <BlogPage data={page23Data} />} />
        <Route path="/blog/page24" element={ <BlogPage data={page24Data} />} />
        <Route path="/blog/page25" element={ <BlogPage data={page25Data} />} />
        <Route path="/blog/page26" element={ <BlogPage data={page26Data} />} />
        <Route path="/blog/page40" element={ <BlogPage data={page40Data} />} />
        <Route path="/blog/page41" element={ <BlogPage data={page41Data} />} />
        <Route path="/blog/page42" element={ <BlogPage data={page42Data} />} />
        <Route path="/blog/page43" element={ <BlogPage data={page43Data} />} />
        <Route path="/blog/page44" element={ <BlogPage data={page44Data} />} />
        <Route path="/blog/page45" element={ <BlogPage data={page45Data} />} />
        <Route path="/blog/page46" element={ <BlogPage data={page46Data} />} />
        <Route path="/blog/page47" element={ <BlogPage data={page47Data} />} />
        <Route path="/blog/page48" element={ <BlogPage data={page48Data} />} />
        <Route path="/blog/page49" element={ <BlogPage data={page49Data} />} />
        <Route path="/blog/page51" element={ <BlogPage data={page51Data} />} />
        </Routes>
        <Footer/>
    
      </Router>

      
     
     
    </div>
  );
}

export default App;
